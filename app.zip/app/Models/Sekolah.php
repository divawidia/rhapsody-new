<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sekolah extends Model
{
    protected $table = 'sekolah_sosialisasi';

    protected $fillable = [
        'nama_sekolah',
        'alamat_sekolah',
        'kecamatan',
        'kabupaten',
        'no_hp_wa',
        'google_maps'
    ];

    use HasFactory;
}
