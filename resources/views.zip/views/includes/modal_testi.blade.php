<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="background-color: var(--theme-color3)">
            <div class="modal-header">
                <h5 class="landing-title5 text-center space-top" data-aos="fade-up" data-aos-duration="1000">
                    Ini Beberapa Kisah Orang yang Sudah
                    <FONT COLOR="#CE5423">Terbantu</FONT> Dengan Adanya Program Kami
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="inner-video-box" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="50">
                    <iframe class="video-testi" style=" border-radius:30px" width="315" height="560" src="https://www.youtube.com/embed/1gr3YyeO8QM?si=vTr6hW-eyE_kOEDC" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    {{--                    <a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn position-center popup-video"><i class="fas fa-play"></i></a>--}}
                </div>
            </div>
        </div>
    </div>
</div>
