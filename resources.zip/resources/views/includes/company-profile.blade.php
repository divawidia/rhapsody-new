<section class="py-5" style="background-color: #FAF5F0;">
    <div class="container">
        <div class="title-area text-center">
            <h2 class="sec-title h1 text-uppercase" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="100">APA AJA YANG ADA DI RHAPSODY?</h2>
            <span class="sec-subtitle" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="200">Program dan Fasilitas yang Siap Mengantarkan Kalian ke Industri</span>
        </div>
        <div class="mt-5 row" data-aos="fade-up-right" data-aos-duration="1000" data-aos-delay="200">
            <div class="img-box3">

                <div class="img-1 mega-hover">
                    <iframe class="company-profile" src="https://www.youtube-nocookie.com/embed/PrNQ-AXWI7U?si=frSi6Ro-VHT9leZd" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</section>
