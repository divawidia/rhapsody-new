<!--==============================
    Preloader
==============================-->
<div class="preloader">
    <button class="vs-btn preloaderCls">CANCEL PRELOADER</button>
    <div class="preloader-inner">
        <img class="w-90" src="/img/logo-2.png" alt="Rhapsody">
        <div class="loader"></div>
    </div>
</div>