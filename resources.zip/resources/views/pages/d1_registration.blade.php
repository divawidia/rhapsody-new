@extends('layouts.app')

@section('title')
    Registrasi Diploma 1 | LPK Rhapsody Hospitality Development Center
@endsection

@section('content')
    <div class="modal fade" id="modalTesti" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content py-3 px-3" style="background-color: var(--theme-color3); border-radius: 20px !important;">
                <div class="modal-header">
                    <div class="row">
                        <div class="col-12 d-flex justify-content-end">
                            <button type="button" class="btn-close align-items-end" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="col-12">
                            <h5 class="landing-title5 text-center" data-aos="fade-up" data-aos-duration="1000">
                                Ini Beberapa Kisah Orang yang Sudah
                                <FONT COLOR="#CE5423">Terbantu</FONT> Dengan Adanya Program Kami
                            </h5>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="inner-video-box text-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="50">
                        <iframe class="modal-video-testi" style=" border-radius:30px" src="https://www.youtube.com/embed/1gr3YyeO8QM?si=vTr6hW-eyE_kOEDC" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                        {{--                    <a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn position-center popup-video"><i class="fas fa-play"></i></a>--}}
                    </div>
                    <div class="card_wrapper">
                        <div class="container text-center">
                            <div class="row" style="max-width: 700px">
                                <div class="title-area my-4 wow fadeInUp" data-wow-delay="0.3s">
                                    <h5 class="sec-title text-center" data-aos="fade-up" data-aos-duration="1000">Beberapa Alumni Kami</h5>
                                </div>
                                <div class="col-12">
                                    @include('includes.testi-cards')
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div
        class="breadcumb-wrapper d-flex align-items-center"
        style="background: url('/img/bg/top-bg.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            overflow: hidden;
            background-position: center center;"
    >
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title" data-aos="fade-up" data-aos-duration="1000">Registrasi Program Diploma 1<FONT COLOR="#CE5423">.</FONT></h1>
            </div>
        </div>
    </div>
    <section class="py-5">
        <div class="container">
        <form action="{{ route('registrasi-program-d1.store') }}" method="post" enctype="multipart/form-data">
            @csrf
            <h1 class="left-border form-title text-uppercase" data-aos="fade-up" data-aos-duration="1000">Form Registrasi</h1>
            <div class="row">
                    <p class="landing-text2" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="50"></p>
                    <div class="col-12 col-md-6">
                        <div class="feature-style1 form-style4 login" data-aos="fade-up" data-aos-duration="1000">
                            <p class="landing-text2">Pilihan Jurusan Diploma 1</p>
                            <div class="de_form de_radio row mh-75 g-3">
                                @foreach($jurusan_diplomas as $jurusan_diploma)
                                    <div class="radio-img col-6" >
                                        <input id="{{ $jurusan_diploma->id }}" name="jurusan_diploma_id" type="radio" value="{{ $jurusan_diploma->id }}">
                                        <label for="{{ $jurusan_diploma->id }}">
                                            <div class="row d-flex align-items-center">
                                                <div class="col-12 col-xl-4">
                                                    <img class="radio-icon" src="{{ Storage::url($jurusan_diploma->icon) }}" alt="">
                                                </div>
                                                <div class="col-12 col-xl-8 align-items-center">
                                                    {{ $jurusan_diploma->nama_jurusan }}
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                            <div class="form-group mt-4">
                                <label for="namaLengkap">Nama Lengkap</label>
                                <input type="text" autocomplete="off" name="nama_lengkap" id="namaLengkap" placeholder="Isikan nama lengkapmu" required>
                            </div>
                            <div class="form-group">
                                <label for="namaPanggilan">Nama Panggilan</label>
                                <input type="text" autocomplete="off" name="nama_panggilan" id="namaPanggilan" placeholder="Isikan nama panggilan" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Alamat Email</label>
                                <input type="email" autocomplete="off" name="email" id="email" placeholder="Isikan alamat emailmu" required>
                            </div>
                            <div class="form-group">
                                <label for="tanggalLahir">Tanggal Lahir</label>
                                <input type="date" autocomplete="off" name="tanggal_lahir" id="tanggalLahir" placeholder="Isikan tanggal lahirmu" required>
                            </div>
                            <div class="form-group">
                                <label for="umur">Umur</label>
                                <input type="number" autocomplete="off" name="umur" id="umur" min="18" placeholder="Isikan umurmu" required>
                            </div>
                            <div class="form-group">
                                <label for="alamat">Alamat Tempat Tinggal</label>
                                <textarea name="alamat" id="alamat" placeholder="Isikan alamat tempat tinggalmu"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="feature-style1 form-style4 login" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="50">
                            <div class="form-group">
                                <label for="no_hp">No. HP/Whatsapp</label>
                                <input type="tel" autocomplete="off" name="no_hp" id="no_hp" placeholder="Isikan No. HP/Whatsapp" required>
                            </div>
                            <div class="form-group">
                                <label for="noHpOrtu">No. HP/Whatsapp Orang Tua/Wali</label>
                                <input type="tel" autocomplete="off" name="no_hp_ortu" id="noHpOrtu" placeholder="Isikan No. HP/Whatsapp Orang Tua/Wali" required>
                            </div>
                            <div class="form-group">
                                <label for="jenisKelamin">Jenis Kelamin</label>
                                <select id="jenisKelamin" class="form-control" name="jenis_kelamin" required>
                                    <option selected>Pilih jenis kelaminmu</option>
                                    <option value="laki-laki">Laki-laki</option>
                                    <option value="perempuan">Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="namaSekolah">Asal Sekolah</label>
                                <input type="text" autocomplete="off" name="asal_sekolah" id="namaSekolah" placeholder="Isikan nama sekolah terakhirmu" required>
                            </div>
                            <div class="form-group">
                                <label for="namaJurusan">Jurusan Sekolah</label>
                                <input type="text" autocomplete="off" name="jurusan_sekolah" id="namaJurusan" placeholder="Isikan nama jurusan di sekolah terakhirmu" required>
                            </div>
                            <div class="form-group">
                                <label for="tahunLulus">Tahun Lulus</label>
                                <input type="number" autocomplete="off" name="tahun_lulus" id="tahunLulus" placeholder="Isikan tahun lulus sekolah terakhirmu" min="2000" max="2023" step="1" required>
                            </div>
                            <div class="form-group">
                                <label for="referral_code">Kode Referral (Opsional)</label>
                                <input type="text" autocomplete="off" name="referral_code" id="referral_code" placeholder="Isikan kode referral" required>
                            </div>
                            <p class="landing-text2 mt-3">Darimana kamu mengetahui Rhapsody? :</p>
                            <div class="row">
                                @foreach($references as $reference)
                                    <div class="col-4">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" name="reference_id[]" id="reference{{ $reference->id }}" value="{{ $reference->id }}">
                                            <label class="form-check-label" for="reference{{ $reference->id }}">{{ $reference->jenis }}</label>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                            <input type="text" autocomplete="off" name="jenis_refrensi" class="mt-3" id="yangLainText" placeholder="Isikan darimana kamu mengetahui rhapsody">
                            <div class="col-12 text-center mt-4">
                                <button type="submit" class="vs-btn">Daftar Sekarang</button>
                            </div>
                        </div>
                    </div>
            </div>
        </form>
        </div>
    </section>
@endsection

@push('addon-script')
    <script>
        function slider_carouselInit() {
            $('.owl-carousel.slider_carousel').owlCarousel({
                dots: false,
                rewind: true,
                autoplay: false,
                nav: true,
                navText: ["<img src='/img/icon/left.png'>", "<img src='/img/icon/next.png'>"],
                responsive: {
                    0: {
                        items: 1
                    }
                }
            });
        }

        slider_carouselInit();
    </script>
    <script>
        $(document).ready(function(){
            $("#modalTesti").modal('show');
        });
    </script>
    <script>
        $(".form-check-input").change(function () {
            //check if the selected option is others
            if (this.value === '9') {
                //toggle textbox visibility
                $("#yangLainText").toggle();
            }
        });
        document.getElementById("tanggalLahir").max = "2005-12-31";
    </script>
@endpush
